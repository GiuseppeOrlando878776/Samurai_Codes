/*
 *  
 *
 *  Created by Khaled SALEH on 05/02/24.
 *
 */


/*==================================================================================
 Khaled SALEH: 	schema de Rusanov pour Baer-Nunziato (convection) avec énergies
 
 
 Février 2024
 ====================================================================================*/

#include <iostream>
#include <fstream>
#include <math.h>
#include <time.h>
#include <cstdio>
#include <cstdlib>
#include <sstream>
#include <string>
#include <cstring>


#include "./fichiershpp/etat.hpp"
#include "./fichiershpp/eos.hpp"
#include "./fichiershpp/Riemannsol.hpp"
#include "./fichiershpp/flux_numeriques.hpp"
#include "./fichiershpp/exactsol.hpp"

using namespace std;

/* ================================================================== */
/*                                                                    */
/*                      PROCEDURE PRINCIPALE                          */
/*                                                                    */
/* ================================================================== */

int main(int argc, char** argv) 
{
	
        /* ============================= */
	/* = Declaration des variables = */
	/* ============================= */
	
	// Variables pour le maillage
	double l, x, xmin, xmax, xz, dx, cfl, umax, umaxx, unmaxx, umaxs, unmaxs, uloc;
	double tmax, t, dt, tempal1, tempal2, tempmom2, tempmom3;
	int ntotal, i, n;
	Etat Umoins, Uplus, fRs, fWmoins, fWplus;
	
	time_t debut, fin;
	double duree;

	double eps;
	
	// Variable d'etat
	Etat *Wb;
	
	// Bilans de maille dflux[i]=fluxg[i+1/2]-fluxd[i-1/2]
	Etat *dfWb;
        
        // Bilans de maille pour la partie non conservative du flux
	Etat *dncvWb;

        // Flux entrant pour les donnees. Va lire dans le fichier init
        ifstream initFile("init");
	
        cout.precision(15);
	
	/* ==================================================== */
	/* = Données thermo des 2 phases                      = */
	/* ==================================================== */
        
        // Phase 1 Stiffened gas p_1(r1,e1)=(Gamma1-1.)*r1*e1-Gamma1*pp1
        read_line(initFile) >> Gamma1;
        read_line(initFile) >> pp1;
        
        // Phase 2 Stiffened gas p_2(r2,e2)=(Gamma2-1.)*r2*e2-Gamma2*pp2
        read_line(initFile) >> Gamma2;
        read_line(initFile) >> pp2;
        
	
	/* ==================================================== */
	/* = Initialisation du maillage et allocation memoire = */
	/* ==================================================== */
	
	cfl = 0.45;
        
        read_line(initFile) >> ntotal;
        read_line(initFile) >> xmin;
        read_line(initFile) >> xmax;
        read_line(initFile) >> xz;
        read_line(initFile) >> tmax;
        read_line(initFile) >> eps;

        
        if (argc == 2)
        {
            ntotal = 100*pow(2,atoi(argv[1]));
        }
	
	l   = xmax-xmin;
	dx  = l/(double)ntotal;
	n   = 0;
        
	 // créer un flux de sortie
    	std::ostringstream oss;
    	// écrire un nombre dans le flux
    	oss << ntotal;
    	// récupérer une chaîne de caractères
    	std::string Ntot = oss.str();
	
	// Fichier resultat : buffer
	string nomfichier = "./resultats/res_rusanov" + Ntot + ".dat";
	size_t size = 	nomfichier.size() + 1;
	char * buffer = new char[ size ];
    	//copier la chaîne
    	strncpy( buffer, nomfichier.c_str(), size );
	
	
	// Fichier de sauvegarde
	FILE *res;
	
	// Fichier pour l'erreur
	FILE *err;
	char nom_err[30] = "./resultats/ErrL1rusanov.dat";
	
	
	// rusabov
	Wb	= new Etat[ntotal+2];
	dfWb	= new Etat[ntotal+1];
        dncvWb	= new Etat[ntotal+1];
		
	/* ====================== */
	/* = Condition initiale = */
	/* ====================== */
	
	double al1g, r1g, u1g, p1g, r2g, u2g, p2g;
	double al1d, r1d, u1d, p1d, r2d, u2d, p2d;
	
       	read_line(initFile) >> al1g >> al1d;
	
	read_line(initFile) >> r1g >> r1d;
	
	read_line(initFile) >> u1g >> u1d;
	
	read_line(initFile) >> p1g >> p1d;
	
	read_line(initFile) >> r2g >> r2d;
	
	read_line(initFile) >> u2g >> u2d;

	read_line(initFile) >> p2g >> p2d;
	
	
	        
        
        debut=time(NULL);
	
	double L = (xz-xmin)/dx;
	
	for ( i=0 ; i <=(int)L ; i++ )  
	{
		Wb[i]	= Etat(al1g,al1g*r1g,al1g*r1g*u1g,al1g*r1g*(u1g*u1g/2.+e1(r1g,p1g)),(1.-al1g)*r2g,(1.-al1g)*r2g*u2g,(1.-al1g)*r2g*(u2g*u2g/2.+e2(r2g,p2g)));
	}
	for ( i=(int)L+1 ; i <= ntotal+1 ; i++ ) 
	{
		Wb[i]	= Etat(al1d,al1d*r1d,al1d*r1d*u1d,al1d*r1d*(u1d*u1d/2.+e1(r1d,p1d)),(1.-al1d)*r2d,(1.-al1d)*r2d*u2d,(1.-al1d)*r2d*(u2d*u2d/2.+e2(r2d,p2d)));
	}
	
	/* =================== */
	/* = Boucle en temps = */
	/* =================== */
	
        
        for ( t=0, n=0 ; t<tmax ; t=t+dt, n++ )
        {
		// Conditions aux limites (Neumann homogene)
		Wb[0]		= Wb[1];
		Wb[ntotal+1]	= Wb[ntotal];
		
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		//%%%%% Calcul des flux et du pas de temps pour  RUSANOV  %%%
		
		// Initialisation des bilans de maille et des donnnees stencil
		for ( i=1 ; i<=ntotal ; i++ ) 
		{
			dfWb[i] 	= Etat();
                        dncvWb[i] 	= Etat();
		}

		// Calcul des bilans de maille (boucle sur les interfaces internes)
                for ( i=1, umaxx=0.; i<=ntotal-1 ; i++ )
		{
		//flux Rusanov
			Umoins		= Wb[i];
			Uplus		= Wb[i+1];
			unmaxx		= fluxNumRs(Umoins, Uplus, fRs);
			umaxx		= max(umaxx,unmaxx);
			dfWb[i]   	= dfWb[i]   + fRs;
			dfWb[i+1] 	= dfWb[i+1] - fRs;
		}
		
		// Calcul des flux aux bords du domaine
				
		// A GAUCHE
		Umoins 	= Wb[0];
		Uplus	= Wb[1];
		unmaxx	=fluxNumRs(Umoins, Uplus, fRs);
		umaxx	= max(umaxx,unmaxx);
		dfWb[1] = dfWb[1] - fRs;

		//A DROITE
		Umoins 	= Wb[ntotal];
		Uplus 	= Wb[ntotal+1];
		unmaxx	=fluxNumRs(Umoins, Uplus, fRs);
		umaxx	= max(umaxx,unmaxx);
		dfWb[ntotal]= dfWb[ntotal]   + fRs;
                
                
                  // Calcul de la partie non conservative du flux
		for ( i=1 ; i<=ntotal ; i++ )
		{
			dncvWb[i].al1	   = (Wb[i].alrhou1/Wb[i].alrho1)*(Wb[i+1].al1-Wb[i-1].al1)/2.;
                        dncvWb[i].alrhou1  = - P2(Wb[i])*(Wb[i+1].al1-Wb[i-1].al1)/2.;
                        dncvWb[i].alrhoE1  = - (Wb[i].alrhou1/Wb[i].alrho1)*P2(Wb[i])*(Wb[i+1].al1-Wb[i-1].al1)/2.;
                        dncvWb[i].alrhou2  = - dncvWb[i].alrhou1;
                        dncvWb[i].alrhoE2  = - dncvWb[i].alrhoE1;
                        
		}

		// Calcul du pas de temps:
		dt = min(tmax-t,cfl*dx/umaxx);

		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		//%%%%%%%%%%%%%%%%%%% FIN RUSANOV  %%%%%%%%%%%%%%%%%%%%%%%%%%

		
		
		//Rusanov: Schema numerique: avancement en temps
		for ( i=1 ; i<=ntotal ; i++ ) 
		{
                        Wb[i]		= Wb[i] - (dt/dx)*dfWb[i]-(dt/dx)*dncvWb[i];
		}
		//cout << "t= "<< t << ", dt= " << dt <<", n=" << n <<", umax=" << umaxx << endl;
		// fin de la boucle en temps
	}
	
	fin=time(NULL);
	duree=difftime(fin, debut);
	
	/* ============================ */
	/* = Sauvegarde des resultats = */
	/* ============================ */
	
	
	res = fopen(buffer,"w");
   	if (!res) 
		cout << "ERREUR: Impossible d'ouvrir le fichier " << buffer << endl;
	else 
	{
        	for ( i=1 ; i<=ntotal ; i++ ) 
		{
			x=xmin+(double)i*dx-dx/2.;
                        fprintf(res,"%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\n", 
					x,                      	         // 1
					Wb[i].al1,			         // 2
                                        1.-Wb[i].al1,		                 // 3
                                        Wb[i].alrho1,			         // 4
					Wb[i].alrhou1,		                 // 5
					Wb[i].alrho1/Wb[i].al1,		         // 6
					Wb[i].alrhou1/Wb[i].alrho1,	         // 7
					c1(Wb[i]),		 // 8
					P1(Wb[i]),		 // 9
					Wb[i].alrhoE1,		         // 10
					Wb[i].alrho2,			         // 11
					Wb[i].alrhou2,			         // 12
					Wb[i].alrho2/(1.-Wb[i].al1),   	         // 13
					Wb[i].alrhou2/Wb[i].alrho2,	         // 14	
					c2(Wb[i]),	 // 15
					P2(Wb[i]),	 // 16
					Wb[i].alrhoE2		         // 17
					);									
		}
	}
	fclose(res);
	delete [] buffer;
        
// 	/* ============================================== */
// 	/* = Trace solution exacte                        */
// 	/* ===============================================*/        
        
        // Fichier de sauvegarde	
	FILE *exact;
	char nom_exact[30] = "./resultats/exact.dat";
	exact = fopen(nom_exact, "w");

	int Ntotal = 50000;
	double Dx = l/(double)Ntotal;
	
	
////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////

	if (!exact) 
		cout << "ERREUR: Impossible d'ouvrir le fichier " << nom_exact << endl;
	else 
	{
        //cout << "avant affic " << endl;
		//    cout << "Sauvegarde des resultats" << endl;
		for ( i=1 ; i<=Ntotal ; i++ ) 
		{	x=xmin+(double)i*Dx-Dx/2.;
			fprintf(exact,"%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\n", 
					x,			               // 1
					Wex(x,t).al1,			       // 2
                                        1.-Wex(x,t).al1,		       // 3
                                        Wex(x,t).alrho1,	               // 4
					Wex(x,t).alrhou1,		        // 5
					Wex(x,t).alrho1/Wex(x,t).al1,		// 6
					Wex(x,t).alrhou1/Wex(x,t).alrho1,	// 7
					c1(Wex(x,t)),	// 8
					P1(Wex(x,t)),	// 9
					Wex(x,t).alrhoE1,		// 10
					Wex(x,t).alrho2,			// 11
					Wex(x,t).alrhou2,			// 12
					Wex(x,t).alrho2/(1.-Wex(x,t).al1),      // 13
					Wex(x,t).alrhou2/Wex(x,t).alrho2,	// 14	
					c2(Wex(x,t)),	// 15
					P2(Wex(x,t)),	// 16
					Wex(x,t).alrhoE2		// 17
					);				
		}
	}
	fclose(exact);	
        
	
        
// 	/* ============================================== */
// 	/* = Calcul de l'erreur en norme L1 =             */
// 	/* ===============================================*/
// 	
// 	
// 	// Erreurs L1 a T=tmax
	double	erral1=0.; 
	double	erralrho1=0.;
	double	erralrhou1=0.;
	double	errrho1=0.;
	double	erru1=0.;
	double	erralrhoE1=0.;
	double	errp1 = 0.;
	double	erralrho2=0.;
	double	erralrhou2=0.;
	double	errrho2=0.;
	double	erru2=0.;
	double	erralrhoE2=0.;
	double	errp2 = 0.;
	double	errQtot=0.;
	double	errEnertot=0.;
	
	// Renormalisation L1 (norme L1 de la vrai solution)
	double	Erral1=0.; 
	double	Erralrho1=0.;
	double	Erralrhou1=0.;
	double	Errrho1=0.;
	double	Erru1=0.;
	double	ErralrhoE1=0.;
	double	Errp1 = 0.;
	double	Erralrho2=0.;
	double	Erralrhou2=0.;
	double	Errrho2=0.;
	double	Erru2=0.;
	double	ErralrhoE2=0.;
	double	Errp2 = 0.;
	double	ErrQtot=0.;
	double	ErrEnertot=0.;
	
	
// 	
	for ( i=1 ; i<=ntotal ; i++ )
	{
		x=xmin+(double)i*dx-dx/2.;
		
		erral1		= erral1	+ fabs(Wb[i].al1-Wex(x,tmax).al1)*dx;
		erralrho1	= erralrho1	+ fabs(Wb[i].alrho1-Wex(x,tmax).alrho1)*dx;
		erralrhou1	= erralrhou1	+ fabs(Wb[i].alrhou1-Wex(x,tmax).alrhou1)*dx;
		errrho1		= errrho1	+ fabs(Wb[i].alrho1/Wb[i].al1-Wex(x,tmax).alrho1/Wex(x,tmax).al1)*dx;
		erru1		= erru1		+ fabs(Wb[i].alrhou1/Wb[i].alrho1-Wex(x,tmax).alrhou1/Wex(x,tmax).alrho1)*dx;
		erralrhoE1	= erralrhoE1	+ fabs(Wb[i].alrhoE1-Wex(x,tmax).alrhoE1)*dx;
		errp1		= errp1		+ fabs(P1(Wb[i])-P1(Wex(x,tmax)))*dx;
		
		erralrho2	= erralrho2	+ fabs(Wb[i].alrho2-Wex(x,tmax).alrho2)*dx;
		erralrhou2	= erralrhou2	+ fabs(Wb[i].alrhou2-Wex(x,tmax).alrhou2)*dx;
		errrho2		= errrho2	+ fabs(Wb[i].alrho2/(1.-Wb[i].al1)-Wex(x,tmax).alrho2/(1.-Wex(x,tmax).al1))*dx;
		erru2		= erru2		+ fabs(Wb[i].alrhou2/Wb[i].alrho2-Wex(x,tmax).alrhou2/Wex(x,tmax).alrho2)*dx;
		erralrhoE2	= erralrhoE2	+ fabs(Wb[i].alrhoE2-Wex(x,tmax).alrhoE2)*dx;
		errp2		= errp2		+ fabs(P2(Wb[i])-P2(Wex(x,tmax)))*dx;
		
		errQtot		= errQtot	+ fabs(Wb[i].alrhou1+Wb[i].alrhou2-Wex(x,tmax).alrhou1-Wex(x,tmax).alrhou2)*dx;
		errEnertot	= errEnertot	+ fabs(Wb[i].alrhoE1+Wb[i].alrhoE2-Wex(x,tmax).alrhoE1-Wex(x,tmax).alrhoE2)*dx;
		
	// Renormalisation
		Erral1		= Erral1	+ fabs(Wex(x,tmax).al1)*dx;
		Erralrho1	= Erralrho1	+ fabs(Wex(x,tmax).alrho1)*dx;
		Erralrhou1	= Erralrhou1	+ fabs(Wex(x,tmax).alrhou1)*dx;
		Errrho1		= Errrho1	+ fabs(Wex(x,tmax).alrho1/Wex(x,tmax).al1)*dx;
		Erru1		= Erru1		+ fabs(Wex(x,tmax).alrhou1/Wex(x,tmax).alrho1)*dx;
		ErralrhoE1	= ErralrhoE1	+ fabs(Wex(x,tmax).alrhoE1)*dx;
		Errp1		= Errp1		+ fabs(P1(Wex(x,tmax)))*dx;
		
		Erralrho2	= Erralrho2	+ fabs(Wex(x,tmax).alrho2)*dx;
		Erralrhou2	= Erralrhou2	+ fabs(Wex(x,tmax).alrhou2)*dx;
		Errrho2		= Errrho2	+ fabs(Wex(x,tmax).alrho2/(1.-Wex(x,tmax).al1))*dx;
		Erru2		= Erru2		+ fabs(Wex(x,tmax).alrhou2/Wex(x,tmax).alrho2)*dx;
		ErralrhoE2	= ErralrhoE2	+ fabs(Wex(x,tmax).alrhoE2)*dx;
		Errp2		= Errp2		+ fabs(P2(Wex(x,tmax)))*dx;
		
		ErrQtot		= ErrQtot	+ fabs(Wex(x,tmax).alrhou1+Wex(x,tmax).alrhou2)*dx;
		ErrEnertot	= ErrEnertot	+ fabs(Wex(x,tmax).alrhoE1+Wex(x,tmax).alrhoE2)*dx;
		
	}
// 	
	erral1		= erral1/Erral1;
	erralrho1	= erralrho1/Erralrho1;
	erralrhou1	= erralrhou1/Erralrhou1;
	errrho1		= errrho1/Errrho1;
	erru1		= erru1/Erru1;
	erralrhoE1	= erralrhoE1/ErralrhoE1;
	errp1		= errp1/Errp1;
	
	erralrho2	= erralrho2/Erralrho2;
	erralrhou2	= erralrhou2/Erralrhou2;
	errrho2		= errrho2/Errrho2;
	erru2		= erru2/Erru2;
	erralrhoE2	= erralrhoE2/ErralrhoE2;
	errp2		= errp2/Errp2;
	
	errQtot		= errQtot/ErrQtot;
	errEnertot	= errEnertot/ErrEnertot;
// 	
// 	
	err = fopen(nom_err,"a+");
   	if (!err) 
		cout << "ERREUR: Impossible d'ouvrir le fichier " << nom_err << endl;
	else 
	{
		fprintf	(err,"%lf\t%.15lf\t%lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\n", 
				duree,			// 1
				dx,			// 2
				erral1,			// 3
				erralrho1,		// 4	
				erralrhou1,		// 5
				errrho1,		// 6
				erru1,			// 7
				erralrhoE1,		// 8
				errp1,			// 9
				erralrho2,		// 10
				erralrhou2,		// 11
				errrho2,		// 12
				erru2,			// 13
				erralrhoE2,		// 14
				errp2,			// 15
				errQtot,		// 16
				errEnertot		// 17
			);						
	}
	fclose(err);
// 	
	
	/* ==================== */
	/* = FIN !!!!!!!!!!!! = */
	/* ==================== */

	/* ==================== */
	/* = FIN !!!!!!!!!!!! = */
	/* ==================== */
	
	
	return 0;
}


