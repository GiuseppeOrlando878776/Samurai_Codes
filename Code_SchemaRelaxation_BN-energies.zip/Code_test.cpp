/*
 *  
 *
 *  Created by Khaled SALEH on 05/02/24.
 *
 */


/*================================================================================================
 Khaled SALEH: 	schemas de Rusanov et de relaxation pour Baer-Nunziato (convection) avec énergies
 
 
 Février 2024
 ================================================================================================*/

#include <iostream>
#include <fstream>
#include <math.h>
#include <cstdio>
#include <cstdlib>

#include "./fichiershpp/etat.hpp"
#include "./fichiershpp/eos.hpp"
#include "./fichiershpp/Riemannsol.hpp"
#include "./fichiershpp/flux_numeriques.hpp"
//#include "./fichiershpp/exactsol.hpp"

using namespace std;

/* ================================================================== */
/*                                                                    */
/*                      PROCEDURE PRINCIPALE                          */
/*                                                                    */
/* ================================================================== */

int main(void) 
{
	
	/* ============================= */
	/* = Declaration des variables = */
	/* ============================= */
	
	// Variables pour le maillage
	double l, xmin, xmax, xz, dx, cfl, umax, umaxx, unmaxx, umaxs, unmaxs;
	double tmax, t, dt, tempal1, tempal2, tempmom2, tempmom3, uloc, eps;
	int ntotal, i, n, ptfix, dissip, ptfixmax;
	Etat Umoins, Uplus, fRs, fWmoins, fWplus;

	// Variable d'etat
	Etat *W, *Wb;
	
	// Bilans de maille dflux[i]=fluxg[i+1/2]-fluxd[i-1/2]
	Etat *dfW, *dfWb, *dncvWb;

	// Fichier de sauvegarde
	FILE *res;
	char nom_res[30] = "./resultats/res_relax.dat";
	
	FILE *res1;
	char nom_res1[30] = "./resultats/res_rusanov.dat";

	// Fichier pour le nombre d'iterations du point fix
	FILE *iter;
	char nom_iter[30] = "./resultats/iterptfix.dat";
	
	// Fichier pour indiquer si ou dissipe ou non
	FILE *diss;
	char nom_diss[30] = "./resultats/dissip.dat";
        
        // Flux entrant pour les donnees. Va lire dans le fichier init
        ifstream initFile("init");
	
	cout.precision(15);
        
        
        
        /* ==================================================== */
	/* = Données thermo des 2 phases                      = */
	/* ==================================================== */
        
         // Phase 1 Stiffened gas p_1(r1,e1)=(Gamma1-1.)*r1*e1-Gamma1*pp1
        read_line(initFile) >> Gamma1;
        read_line(initFile) >> pp1;
        
        // Phase 2 Stiffened gas p_2(r2,e2)=(Gamma2-1.)*r2*e2-Gamma2*pp2
        read_line(initFile) >> Gamma2;
        read_line(initFile) >> pp2;
        
        
	/* ==================================================== */
	/* = Initialisation du maillage et allocation memoire = */
	/* ==================================================== */
	
	cfl = 0.45;
        
        read_line(initFile) >> ntotal;
        read_line(initFile) >> xmin;
        read_line(initFile) >> xmax;
        read_line(initFile) >> xz;
        read_line(initFile) >> tmax;
        read_line(initFile) >> eps;

	
	l   = xmax-xmin;
	dx  = l/(double)ntotal;
	n   = 0;
        
	
	// relaxation
	W	= new Etat[ntotal+2];
	dfW	= new Etat[ntotal+1];
	
	// Rusanov
	Wb	= new Etat[ntotal+2];
	dfWb	= new Etat[ntotal+1];
        dncvWb	= new Etat[ntotal+1];
         
	/* ====================== */
	/* = Condition initiale = */
	/* ====================== */
	
	double al1g, r1g, u1g, p1g, r2g, u2g, p2g;
	double al1d, r1d, u1d, p1d, r2d, u2d, p2d;
	
        
        read_line(initFile) >> al1g >> al1d;
	
	read_line(initFile) >> r1g >> r1d;
	
	read_line(initFile) >> u1g >> u1d;
	
	read_line(initFile) >> p1g >> p1d;
	
	read_line(initFile) >> r2g >> r2d;
	
	read_line(initFile) >> u2g >> u2d;

	read_line(initFile) >> p2g >> p2d;
	
	
	
	double L = (xz-xmin)/dx;
        
	
	for ( i=0 ; i <=(int)L ; i++ )  
	{
		W[i]	= Etat(al1g,al1g*r1g,al1g*r1g*u1g,al1g*r1g*(u1g*u1g/2.+e1(r1g,p1g)),(1.-al1g)*r2g,(1.-al1g)*r2g*u2g,(1.-al1g)*r2g*(u2g*u2g/2.+e2(r2g,p2g)));
                Wb[i]	= Etat(al1g,al1g*r1g,al1g*r1g*u1g,al1g*r1g*(u1g*u1g/2.+e1(r1g,p1g)),(1.-al1g)*r2g,(1.-al1g)*r2g*u2g,(1.-al1g)*r2g*(u2g*u2g/2.+e2(r2g,p2g)));
	}
	for ( i=(int)L+1 ; i <= ntotal+1 ; i++ ) 
	{
		W[i]	= Etat(al1d,al1d*r1d,al1d*r1d*u1d,al1d*r1d*(u1d*u1d/2.+e1(r1d,p1d)),(1.-al1d)*r2d,(1.-al1d)*r2d*u2d,(1.-al1d)*r2d*(u2d*u2d/2.+e2(r2d,p2d)));
                Wb[i]	= Etat(al1d,al1d*r1d,al1d*r1d*u1d,al1d*r1d*(u1d*u1d/2.+e1(r1d,p1d)),(1.-al1d)*r2d,(1.-al1d)*r2d*u2d,(1.-al1d)*r2d*(u2d*u2d/2.+e2(r2d,p2d)));
	}
	
	
	// naff : nbre d'affichages
	int naff, iaff = 0, affiche;
	 
        // on affiche ou pas ?
        read_line(initFile) >> affiche;
	//nb d'affichage
        read_line(initFile) >> naff;
	
		
	/* =================== */
	/* = Boucle en temps = */
	/* =================== */
	
	
	iter = fopen(nom_iter,"a+");
	diss = fopen(nom_diss,"a+");
        
	if (affiche == 1)
        {
            cout << "set terminal x11   " << endl;
            cout << "set style line 1 lt 1 lw 4 pt 1 lc rgb 'black'  " << endl;
            cout << "set style line 2 lt 1 lw 2 pt 7 lc rgb 'red'  " << endl;
            cout << "set style line 3 lt 1 lw 2 pt 4 lc rgb 'blue' " << endl;
        }
        
	for ( t=0, n=0 ; t<tmax ; t=t+dt, n++ )
        //for ( t=0, n=0 ; n<2 ; t=t+dt, n++ ) 
	{
		//cout << "n= " << n << endl;
                ptfixmax = 0;
		
		// Conditions aux limites (Neumann homogene)
		W[0]		= W[1];
		W[ntotal+1]	= W[ntotal];

		Wb[0]		= Wb[1];
		Wb[ntotal+1]	= Wb[ntotal];

		
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		//%%%%% Calcul des flux et du pas de temps pour  RUSANOV  %%%
		
		// Initialisation des bilans de maille et des donnnees stencil
		//cout << "Initialisation des bilans de maille et des donnnees stencil" << endl;
		for ( i=1 ; i<=ntotal ; i++ ) 
		{
			dfWb[i] 	= Etat();
                        dncvWb[i] 	= Etat();
		}

		// Calcul des bilans de maille (boucle sur les interfaces internes)
		//cout << "Calcul des bilans de maille (boucle sur les interfaces internes)" << endl;
		for ( i=1, umaxx=0.; i<=ntotal-1 ; i++ )
		{
		//flux Rusanov
			Umoins		= Wb[i];
			Uplus		= Wb[i+1];
			unmaxx		= fluxNumRs(Umoins, Uplus, fRs);
			umaxx		= max(umaxx,unmaxx);
			dfWb[i]   	= dfWb[i]   + fRs;
			dfWb[i+1] 	= dfWb[i+1] - fRs;
		}
		
		// Calcul des flux aux bords du domaine
				
		// A GAUCHE
		Umoins 	= Wb[0];
		Uplus	= Wb[1];
		unmaxx	=fluxNumRs(Umoins, Uplus, fRs);
		umaxx	= max(umaxx,unmaxx);
		dfWb[1] = dfWb[1] - fRs;

		//A DROITE
		Umoins 	= Wb[ntotal];
		Uplus 	= Wb[ntotal+1];
		unmaxx	=fluxNumRs(Umoins, Uplus, fRs);
		umaxx	= max(umaxx,unmaxx);
		dfWb[ntotal]= dfWb[ntotal]   + fRs;
                
                
                // Calcul de la partie non conservative du flux
		for ( i=1 ; i<=ntotal ; i++ )
		{
			dncvWb[i].al1	   = (Wb[i].alrhou1/Wb[i].alrho1)*(Wb[i+1].al1-Wb[i-1].al1)/2.;
                        dncvWb[i].alrhou1  = - P2(Wb[i])*(Wb[i+1].al1-Wb[i-1].al1)/2.;
                        dncvWb[i].alrhoE1  = - (Wb[i].alrhou1/Wb[i].alrho1)*P2(Wb[i])*(Wb[i+1].al1-Wb[i-1].al1)/2.;
                        dncvWb[i].alrhou2  = - dncvWb[i].alrhou1;
                        dncvWb[i].alrhoE2  = - dncvWb[i].alrhoE1;
                        
		}

		// Calcul du pas de temps:
		dt = min(tmax-t,cfl*dx/umaxx);

		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		//%%%%%%%%%%%%%%%%%%% FIN RUSANOV  %%%%%%%%%%%%%%%%%%%%%%%%%%
		
		
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		//%%%%% Calcul des flux et du pas de temps pour RELAXATION %%%
		
		// Initialisation des bilans de maille et des donnnees stencil
		for ( i=1 ; i<=ntotal ; i++ ) 
		{
			dfW[i] 	= Etat();
		}

		// Calcul des bilans de maille (boucle sur les interfaces internes)
		for ( i=1, umaxx=0.; i<=ntotal-1 ; i++ )
		{
                //cout << "i =" << i << endl;
		//flux Relax
			Umoins		= W[i];
			Uplus		= W[i+1];
			unmaxx		= flux_relax(Umoins, Uplus, fWmoins, fWplus, ptfix, dissip, eps);
			umaxx		= max(umaxx,unmaxx);
			ptfixmax	= max(ptfixmax,ptfix);
			dfW[i]   	= dfW[i]   + fWmoins;
			dfW[i+1] 	= dfW[i+1] - fWplus;
			if (dissip==1) fprintf(diss,"%.10lf\t%d\t%d\t%d\n",t,n,i,i+1);
			
		}
		
		// Calcul des flux aux bords du domaine
				
		// A GAUCHE
		Umoins 	= W[0];
		Uplus	= W[1];
		unmaxx	= flux_relax(Umoins, Uplus, fWmoins, fWplus, ptfix, dissip, eps);
		umaxx	= max(umaxx,unmaxx);
		ptfixmax= max(ptfixmax,ptfix);
		dfW[1] 	= dfW[1] - fWplus;
		if (dissip==1) fprintf(diss,"%.10lf\t%d\t%d\t%d\n",t,n,0,1);
// 		
			

		//A DROITE
		Umoins 	= W[ntotal];
		Uplus 	= W[ntotal+1];
		unmaxx	= flux_relax(Umoins, Uplus, fWmoins, fWplus, ptfix, dissip, eps);
		umaxx	= max(umaxx,unmaxx);
		ptfixmax= max(ptfixmax,ptfix);
		dfW[ntotal] = dfW[ntotal]   + fWmoins;
		if (dissip==1) fprintf(diss,"%.10lf\t%d\t%d\t%d\n",t,n,ntotal,ntotal+1);
			
		// Calcul du pas de temps:
		dt = min(dt,min(tmax-t,cfl*dx/umaxx));
//
// 		
// 		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// 		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// 		//%%%%%%%%%%%%%%%%%%% FIN RELAXATION %%%%%%%%%%%%%%%%%%%%%%%%%

				
		
		//Rusanov: Schema numerique: avancement en temps
		for ( i=1 ; i<=ntotal ; i++ ) 
		{
                        Wb[i]		= Wb[i] - (dt/dx)*dfWb[i]-(dt/dx)*dncvWb[i];
		}
		
		
		//Relaxation: Schema numerique: avancement en temps
		for ( i=1 ; i<=ntotal ; i++ ) 
		{
			W[i]		= W[i]- (dt/dx)*dfW[i];
		}
		
		
		
                fprintf(iter,"%.10lf\t%d\n",t,ptfixmax);
		
                //cout << "t= "<< t << ", dt= " << dt <<", n=" << n <<", umax=" << umaxx << endl;

		/*====================================================
		 Affichage en continu
		 ======================================================*/
		
		if (affiche == 1) 
		{
		
		if ((t<=iaff*tmax/naff)&&(iaff*tmax/naff<=t+dt)&&(affiche=1)) 
		{
			
			iaff++;
			cout << "set grid" << endl;
						
                        // On affiche tout !
			cout << "set multiplot                            " << endl;
			cout << "set size 0.5,0.25                        " << endl;
                             

			cout << "set origin 0.0,0.75                       " << endl;
			cout << "set title 'alpha_1"<< "- " << floor(t/tmax*100) << " %'" << endl;
			cout << "plot [" << xmin << ":" << xmax << "]  '-' w lp ls 3 tit 'Rusanov','-' w lp ls 2 tit 'Relax'" << endl;
			for ( i=1 ; i<=ntotal ; i++ )
                                cout << xmin+(double)i*dx-dx/2. << " " << Wb[i].al1 << endl;
                        cout << "e                                        " << endl;
			for ( i=1 ; i<=ntotal ; i++ )
				cout << xmin+(double)i*dx-dx/2. << " " << W[i].al1 << endl;
			cout << "e                                        " << endl;
				
							
			cout << "set origin 0.0,0.5                       " << endl;
			cout << "set title 'u_1"<< "- " << floor(t/tmax*100) << " %'" << endl;
			cout << "plot [" << xmin << ":" << xmax << "]  '-' w lp ls 3 tit 'Rusanov','-' w lp ls 2 tit 'Relax'" << endl;
			for ( i=1 ; i<=ntotal ; i++ )
				cout << xmin+(double)i*dx-dx/2. << " " << Wb[i].alrhou1/Wb[i].alrho1 << endl;
			cout << "e                                        " << endl;
			for ( i=1 ; i<=ntotal ; i++ )
				cout << xmin+(double)i*dx-dx/2. << " " << W[i].alrhou1/W[i].alrho1 << endl;
			cout << "e                                        " << endl;
			
       			cout << "set origin 0.0,0.25                       " << endl;
			cout << "set title 'Densite Phase 1"<< "- " << floor(t/tmax*100) << " %'" << endl;
			cout << "plot [" << xmin << ":" << xmax << "]  '-' w lp ls 3 tit 'Rusanov', '-' w lp ls 2 tit 'Relax'" << endl;
			for ( i=1 ; i<=ntotal ; i++ )
				cout << xmin+(double)i*dx-dx/2. << " " << Wb[i].alrho1/Wb[i].al1 << endl;
			cout << "e                                        " << endl;
			for ( i=1 ; i<=ntotal ; i++ )
				cout << xmin+(double)i*dx-dx/2. << " " << W[i].alrho1/W[i].al1 << endl;
			cout << "e                                        " << endl;
                        
                        cout << "set origin 0.0,0.0                       " << endl;
			cout << "set title 'Pression Phase 1"<< "- " << floor(t/tmax*100) << " %'" << endl;
			cout << "plot [" << xmin << ":" << xmax << "]  '-' w lp ls 3 tit 'Rusanov', '-' w lp ls 2 tit 'Relax'" << endl;
			for ( i=1 ; i<=ntotal ; i++ )
				cout << xmin+(double)i*dx-dx/2. << " " << P1(Wb[i]) << endl;
			cout << "e                                        " << endl;
			for ( i=1 ; i<=ntotal ; i++ )
				cout << xmin+(double)i*dx-dx/2. << " " << P1(W[i]) << endl;
			cout << "e                                        " << endl;


                        
                        cout << "set origin 0.5,0.75                       " << endl;
			cout << "set title 'alpha_2"<< "- " << floor(t/tmax*100) << " %'" << endl;
			cout << "plot [" << xmin << ":" << xmax << "]  '-' w lp ls 3 tit 'Rusanov','-' w lp ls 2 tit 'Relax'" << endl;
			for ( i=1 ; i<=ntotal ; i++ )
                                cout << xmin+(double)i*dx-dx/2. << " " << 1.-Wb[i].al1 << endl;
                        cout << "e                                        " << endl;
			for ( i=1 ; i<=ntotal ; i++ )
				cout << xmin+(double)i*dx-dx/2. << " " << 1.-W[i].al1 << endl;
			cout << "e                                        " << endl;
                        
                        cout << "set origin 0.5,0.5                       " << endl;
			cout << "set title 'u_2"<< "- " << floor(t/tmax*100) << " %'" << endl;
			cout << "plot [" << xmin << ":" << xmax << "]  '-' w lp ls 3 tit 'Rusanov','-' w lp ls 2 tit 'Relax'" << endl;
			for ( i=1 ; i<=ntotal ; i++ )
				cout << xmin+(double)i*dx-dx/2. << " " << Wb[i].alrhou2/Wb[i].alrho2 << endl;
			cout << "e                                        " << endl;
			for ( i=1 ; i<=ntotal ; i++ )
				cout << xmin+(double)i*dx-dx/2. << " " << W[i].alrhou2/W[i].alrho2 << endl;
			cout << "e                                        " << endl;
					
			cout << "set origin 0.5,0.25                       " << endl;
			cout << "set title 'Densite Phase 2"<< "- " << floor(t/tmax*100) << " %'" << endl;
			cout << "plot [" << xmin << ":" << xmax << "]  '-' w lp ls 3 tit 'Rusanov','-' w lp ls 2 tit 'Relax'" << endl;
			for ( i=1 ; i<=ntotal ; i++ )
				cout << xmin+(double)i*dx-dx/2. << " " << Wb[i].alrho2/(1.-Wb[i].al1) << endl;
			cout << "e                                        " << endl;
			for ( i=1 ; i<=ntotal ; i++ )
				cout << xmin+(double)i*dx-dx/2. << " " << W[i].alrho2/(1.-W[i].al1) << endl;
			cout << "e                                        " << endl;
                        
                        cout << "set origin 0.5,0.0                       " << endl;
			cout << "set title 'Pression Phase 2"<< "- " << floor(t/tmax*100) << " %'" << endl;
			cout << "plot [" << xmin << ":" << xmax << "]  '-' w lp ls 3 tit 'Rusanov','-' w lp ls 2 tit 'Relax'" << endl;
			for ( i=1 ; i<=ntotal ; i++ )
				cout << xmin+(double)i*dx-dx/2. << " " << P2(Wb[i]) << endl;
			cout << "e                                        " << endl;
			for ( i=1 ; i<=ntotal ; i++ )
				cout << xmin+(double)i*dx-dx/2. << " " << P2(W[i]) << endl;
			cout << "e                                        " << endl;
			
			cout << "pause .3" << endl;
			// Fin de l'affichage
		}
		}
		
		// fin de la boucle en temps
	}
	
	fclose(iter);
	fclose(diss);
	
	//  cout << "Fin de la boucle en temps : n = " << n << "." << endl;
	
	/* ============================ */
	/* = Sauvegarde des resultats = */
	/* ============================ */
	
	//cout << "apres bcle en temps " << endl;	
	

	// Relaxation
	res = fopen(nom_res,"w");
   	if (!res) 
		cout << "ERREUR: Impossible d'ouvrir le fichier " << nom_res << endl;
	else 
	{
       	//    cout << "Sauvegarde des resultats" << endl;
		for ( i=1 ; i<=ntotal ; i++ ) 
		{
			fprintf(res,"%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\n", 
					xmin+(double)i*dx-dx/2.,	         // 1
					W[i].al1,			         // 2
                                        1.-W[i].al1,		                 // 3
                                        W[i].alrho1,			         // 4
					W[i].alrhou1,		                 // 5
					W[i].alrho1/W[i].al1,		         // 6
					W[i].alrhou1/W[i].alrho1,	         // 7
					c1(W[i]),		 // 8
					P1(W[i]),		 // 9
					W[i].alrhoE1,		         // 10
					W[i].alrho2,			         // 11
					W[i].alrhou2,			         // 12
					W[i].alrho2/(1.-W[i].al1),     	         // 13
					W[i].alrhou2/W[i].alrho2,	         // 14	
					c2(W[i]),		 // 15
					P2(W[i]),		 // 16
					W[i].alrhoE2		         // 17
					);				
		}
	}
	fclose(res);
	
	
	// RUSANOV
	res1 = fopen(nom_res1,"w");
	//res = fopen("res.dat","w");
   	if (!res1) 
		cout << "ERREUR: Impossible d'ouvrir le fichier " << nom_res1 << endl;
	else 
	{
        //cout << "avant affic " << endl;
		//    cout << "Sauvegarde des resultats" << endl;
		for ( i=1 ; i<=ntotal ; i++ ) 
		{
			fprintf(res1,"%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\t%.15lf\n", 
					xmin+(double)i*dx-dx/2.,	         // 1
					Wb[i].al1,			         // 2
                                        1.-Wb[i].al1,		                 // 3
                                        Wb[i].alrho1,			         // 4
					Wb[i].alrhou1,		                 // 5
					Wb[i].alrho1/Wb[i].al1,		         // 6
					Wb[i].alrhou1/Wb[i].alrho1,	         // 7
					c1(Wb[i]),		 // 8
					P1(Wb[i]),		 // 9
					Wb[i].alrhoE1,		         // 10
					Wb[i].alrho2,			         // 11
					Wb[i].alrhou2,			         // 12
					Wb[i].alrho2/(1.-Wb[i].al1),   	         // 13
					Wb[i].alrhou2/Wb[i].alrho2,	         // 14	
					c2(Wb[i]),		 // 15
					P2(Wb[i]),		 // 16
					Wb[i].alrhoE2		         // 17
					);						
		}
	}
	fclose(res1);


	
	
	/* ==================== */
	/* = FIN !!!!!!!!!!!! = */
	/* ==================== */

	/* ==================== */
	/* = FIN !!!!!!!!!!!! = */
	/* ==================== */
	
	
	return 0;
}


