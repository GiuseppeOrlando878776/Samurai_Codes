#include <iostream>
#include <cstdio>
#include <math.h>
#include <string.h>
#include "../fichiershpp/etat.hpp"
#include "../fichiershpp/eos.hpp"



////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
//////////////    SOLUTION EXACTE           ////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////


Etat Wriem(double xi)
{
	double sigma1g,sigma1d, sigma2g, sigma2d;
	double u1mc1g, u1mc1d;
	double u2mc2g, u2mc2d;
	double u1pc1g, u1pc1d;
	double u2pc2g, u2pc2d; 
	double u2s, u1s;
	
	double al1, rho1, u1, p1, al2, rho2, u2, p2;  
        

// Attention, ce sont des etats en variables non conservatives
	
		
	u1mc1g	= -77.041647368785817;
	u1mc1d	= -50.464334711167417;
        
        u2mc2g	= -57.013869324513088;
	u2mc2d	= -25.417141354155600;

	
	u1s	= -6.308500000000000;	
	u2s	= -1.754045349620180;
	
	sigma2d = 1.815282343537437;	
	sigma1d	= 15.523232651828138;
	
	

	if (xi<u1mc1g) 
	{
                al1     = 0.7;
                rho1	= 1.000039531610579;
		u1	= -19.597156328809199;
		p1	= 1000.0;
                
		al2	= 1.-al1;
		rho2	= 1.000005943124931;
		u2 	= -19.597406641964575;
		p2	= 1000.000;
		
		
		return Etat(al1,al1*rho1,al1*rho1*u1,al1*rho1*(u1*u1/2.+e1(rho1,p1)),al2*rho2,al2*rho2*u2,al2*rho2*(u2*u2/2.+e2(rho2,p2)));
	}  
		
	if (u1mc1g <= xi && xi < u2mc2g)
	{
                al1     = 0.7;
                rho1	= pow(pow(1.000039531610579,(Gamma1-1.)/2.)- (Gamma1-1.)/(Gamma1+1.)/sqrt(Gamma1)/sqrt((1000.+pp1)*pow(1.000039531610579,-Gamma2))*(xi-u1mc1g),2./(Gamma1-1.));
		u1 	=  -19.597156328809199 + 2./(Gamma1+1.)*(xi-u1mc1g);
		p1	= (1000.+pp1)*pow(1.000039531610579,-Gamma1)*pow(rho1,Gamma1)-pp1;
                
                al2	= 1.-al1;
		rho2	= 1.000005943124931;
		u2	= -19.597406641964575;
		p2	= 1000.0;
	  
		
		return Etat(al1,al1*rho1,al1*rho1*u1,al1*rho1*(u1*u1/2.+e1(rho1,p1)),al2*rho2,al2*rho2*u2,al2*rho2*(u2*u2/2.+e2(rho2,p2)));
	}  
	
	if (u2mc2g <= xi && xi <u1mc1d)
	{
		al1	= 0.7;
                rho1	= pow(pow(1.000039531610579,(Gamma1-1.)/2.)- (Gamma1-1.)/(Gamma1+1.)/sqrt(Gamma1)/sqrt((1000.+pp1)*pow(1.000039531610579,-Gamma1))*(xi-u1mc1g),2./(Gamma1-1.));
		u1 	=  -19.597156328809199 + 2./(Gamma1+1.)*(xi-u1mc1g);
		p1	= (1000.+pp1)*pow(1.000039531610579,-Gamma1)*pow(rho1,Gamma1)-pp1;
            
                al2	= 1.-al1;
		rho2	= pow(pow(1.000005943124931,(Gamma2-1.)/2.)- (Gamma2-1.)/(Gamma2+1.)/sqrt(Gamma2)/sqrt((1000.+pp2)*pow(1.000005943124931,-Gamma2))*(xi-u2mc2g),2./(Gamma2-1.));
		u2 	=  -19.597406641964575 + 2./(Gamma2+1.)*(xi-u2mc2g);
		p2	= (1000.+pp2)*pow(1.000005943124931,-Gamma2)*pow(rho2,Gamma2)-pp2;
		
		
		return Etat(al1,al1*rho1,al1*rho1*u1,al1*rho1*(u1*u1/2.+e1(rho1,p1)),al2*rho2,al2*rho2*u2,al2*rho2*(u2*u2/2.+e2(rho2,p2)));
	}
	
	if (u1mc1d <= xi && xi < u2mc2d)
	{	
		al1     = 0.7;
                rho1	= 0.768700000000000;
		u1	= -6.308500000000000;
		p1	= 399.587800000000016;
            
                al2	= 1.-al1;
		rho2	= pow(pow(1.000005943124931,(Gamma2-1.)/2.)- (Gamma2-1.)/(Gamma2+1.)/sqrt(Gamma2)/sqrt((1000.+pp2)*pow(1.000005943124931,-Gamma2))*(xi-u2mc2g),2./(Gamma2-1.));
		u2 	=  -19.597406641964575 + 2./(Gamma2+1.)*(xi-u2mc2g);
		p2	= (1000.+pp2)*pow(1.000005943124931,-Gamma2)*pow(rho2,Gamma2)-pp2;
		
		
		return Etat(al1,al1*rho1,al1*rho1*u1,al1*rho1*(u1*u1/2.+e1(rho1,p1)),al2*rho2,al2*rho2*u2,al2*rho2*(u2*u2/2.+e2(rho2,p2)));
	}
	
	if (u2mc2d <= xi && xi < u1s) 
	{ 
		al1     = 0.7;
                rho1	= 0.768700000000000;
		u1	= -6.308500000000000;
		p1	= 399.587800000000016;
            
                al2	= 1.-al1;
		rho2	= 0.468400000000000;
		u2 	= 6.733200000000000;
		p2	= 345.827900000000000 ;
		
		
		return Etat(al1,al1*rho1,al1*rho1*u1,al1*rho1*(u1*u1/2.+e1(rho1,p1)),al2*rho2,al2*rho2*u2,al2*rho2*(u2*u2/2.+e2(rho2,p2)));
	}  
	
	if (u1s <= xi && xi < u2s) 
	{		
		al1     = 0.2;
                rho1	= 1.608700000000000;
		u1	= -6.308500000000000;
		p1	= 466.725914519491994;
            
                al2	= 1.-al1;
		rho2	= 0.502974511955885;
		u2 	= -1.754045349620180;
		p2	= 382.085674983441322;
		
		return Etat(al1,al1*rho1,al1*rho1*u1,al1*rho1*(u1*u1/2.+e1(rho1,p1)),al2*rho2,al2*rho2*u2,al2*rho2*(u2*u2/2.+e2(rho2,p2)));
	}
	
	if (u2s <= xi && xi < sigma2d)
	{	
		al1     = 0.2;
                rho1	= 1.608700000000000;
		u1	= -6.308500000000000;
		p1	= 466.725914519491994;
                
                al2	= 1.-al1;
		rho2	= 5.999100000000000;
		u2 	= -1.754045349620180;
		p2	= 382.085674983441322;
		
		
		return Etat(al1,al1*rho1,al1*rho1*u1,al1*rho1*(u1*u1/2.+e1(rho1,p1)),al2*rho2,al2*rho2*u2,al2*rho2*(u2*u2/2.+e2(rho2,p2)));
	}
	
	if (sigma2d <= xi && xi < sigma1d)
	{
		al1     = 0.2;
		rho1	= 1.608700000000000;
		u1	= -6.308500000000000;
		p1	= 466.725914519491994;
            
                al2	= 1.-al1;
		rho2	= 1.000002647253587;
		u2 	= -19.597414735645273;
		p2	= 0.01;
		
		
		return Etat(al1,al1*rho1,al1*rho1*u1,al1*rho1*(u1*u1/2.+e1(rho1,p1)),al2*rho2,al2*rho2*u2,al2*rho2*(u2*u2/2.+e2(rho2,p2)));
	}
	
	if (sigma1d <= xi)
	{
                al1     = 0.2;
                rho1	= 1.000001883843073;
		u1	= -19.597409503389336;
		p1	= 0.010000;
                
		al2	= 1.-al1;
		rho2	= 1.000002647253587;
		u2 	= -19.597414735645273;
		p2	= 0.01;
		
		return Etat(al1,al1*rho1,al1*rho1*u1,al1*rho1*(u1*u1/2.+e1(rho1,p1)),al2*rho2,al2*rho2*u2,al2*rho2*(u2*u2/2.+e2(rho2,p2)));
	}        
}

Etat Wex(double x, double t)
{
        double xz = 0.8;
        return Wriem((x-xz)/t);
    
}

